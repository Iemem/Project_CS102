/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package project_cs102;

/**
 *
 * @author ACER
 */
public interface Discountable {

    public static void main(String[] args) {

    }

    public double calculateDiscount(double discountRate);
}


